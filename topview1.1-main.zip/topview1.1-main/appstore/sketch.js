//var obj, objIMG;


function draw() {
  background(0,0,0);    

//if(keyDown(UP_ARROW)){
//plr.y = plr.y-5;
//}

  drawSprites();
}

//var obj, objIMG;

function preload(){
  //objIMG = loadImage("obj.png");
  }
  
  function setup() {
    createCanvas(1800,1400);
    //obj = createSprite(700, 600, 50, 50);
    //obj.addImage(objIMG);
    //obj.scale = 1.5;
  }
  
  function draw() {
    background(0,0,0);    
  
//if(keyDown(UP_ARROW)){
//plr.y = plr.y-5;
//}

    drawSprites();
  }